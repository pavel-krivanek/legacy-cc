struct text
{
	int	x_daddr;
	int	x_caddr;
	int	x_size;
	int	*x_iptr;
	char	x_count;
	char	x_ccount;
} text[NTEXT];
