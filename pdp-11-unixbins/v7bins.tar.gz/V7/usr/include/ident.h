char myname[] = "research 11/70";
