/*
 * Copyright (c) 1987 Regents of the University of California.
 * All rights reserved.  The Berkeley software License Agreement
 * specifies the terms and conditions for redistribution.
 *
 *	@(#)mch_cpu.h	1.2 (2.11BSD GTE) 12/26/92
 */

#define	PDP1170_LEAR	0177740		/* See comments in pdp/cpu.h */
