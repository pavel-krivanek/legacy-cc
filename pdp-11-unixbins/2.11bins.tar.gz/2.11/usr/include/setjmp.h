/*	setjmp.h	4.1	93/12/31	*/

typedef int jmp_buf[10];
