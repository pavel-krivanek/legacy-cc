.fp \np gr
.cs gr 20
.lg 0
