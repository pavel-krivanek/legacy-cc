.fp \np dr
.lg 0
